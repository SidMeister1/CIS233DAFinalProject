/*

New Perspectives on HTML5 and CSS3, 7th Edition
Final Project 
Name: Ayesha Siddiqi

File name: er_formsubmit.js

*/

window.onload = setForm;

function setForm() {
   document.forms[0].onsubmit = function() {
      if (this.checkValidity()) alert("No invalid data detected. Will retain data for further testing.");
      return false;
   }
}
